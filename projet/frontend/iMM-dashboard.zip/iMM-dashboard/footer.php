<footer>
    <div class="container">
        <div class="row ">
            <div class=" col-md-offset-5">
                <div class="copyright text-center">
                    <p>
                        &copy; Copyright, 2021 - IMT Lille Douai - IDAW - iMangerMieux</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>
