<?php 
    include 'nav.php';
?>
<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        
    </div>
    <p class="display-4">Dashboard-y Things</p>
    <p class="text-primary">This is where one might find all sorts of dashboard-y goodness...</p>
    <p class="text-success">Instead, you're seeing Lorem Gibson, which is cooler than Lorem Ipsum, but a little less cool than Lorem Jackson.</p>
    <p class="text-muted">Mostly, you'll find that I'm just finding excuses to use BS4's crazy cool classes...</p>
    <p class="text-danger">Don't be distracted by all of this filler. The cool stuff is in the sidebar nav!</p>
    <p>Military-grade dissident concrete knife RAF warehouse stimulate wonton soup sentient lights sub-orbital modem jeans. Ablative engine kanji sentient order-flow vehicle corporation plastic. Assassin Shibuya woman camera nano-network corrupted cartel boy. Tank-traps into youtube footage bicycle towards cyber-dissident. Futurity bridge modem skyscraper shanty town nodal point hotdog boat cartel A.I. DIY. Systema modem j-pop claymore mine singularity uplink tube systemic 3D-printed
    </p>
</div> <!-- /#admin-main-control -->
        </div> <!-- /.row -->
    </div> <!-- /.container-fluid -->
</body>

<?php 
    include 'footer.php';
?>