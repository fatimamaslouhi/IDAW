function swapStyleSheet() {
        document.getElementById("pagestyle").setAttribute("href", "css/dark.min.css");  

    
}


var toggle = document.getElementById('toggle');

toggle.onclick = function () { console.log('khi') };
