<?php 
    include 'nav.php';
?>
  <script type="application/javascript" src="js/swipemode.js">



<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
 
    
    
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
    <div class="col-2">
    </div>
    <div class="col-8">

<br>
<br>
        <center>
        <div class="row">
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Fluid jumbotron</h1>
    <img src="images/lfabresse.jpg"  width="140" height="140" border="0" class="img-circle">
    <br><br>
    <?php
            $user = "Luc Fabresse";
          echo "<h3 class='text-center'> $user </h3>";
         ?>
    <br>
    <p class="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>

  
  
</div>
</div>

       
    </center>
   
      </div>
	</div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>


<!--Spacer -->
<div class="mx-auto" style="height:180px; width: 200px;"></div>
  



</body>

<?php 
    include 'footer.php';
?>