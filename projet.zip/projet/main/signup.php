<?php 

include 'navlogin.php';

?>

<div id="admin-main-control" class="col-md-10 p-x-3 p-y-1">
    <div class="content-title m-x-auto">
        
    </div>
    <p class="display-4">Sign up</p>
    
    </p>
    <br><br>
<form>
            <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="myEmail">Email</label>
                  <input type="email" class="form-control"
                     id="myEmail" placeholder="Email">
               </div>
               <div class="form-group col-sm-6">
                  <label for="myPassword">Password</label>
                  <input type="password" class="form-control"
                     id="myPassword" placeholder="Password">
               </div>
                </div>
               <div class="form-row">
               <div class="form-group col-sm-2">
               <label for="mySelect1">Gender</label>
               <select id="mySelect1" class="form-control">
                  <option value="js">...</option>
                  <option value="css">Ms</option>
                  <option value="bootstrap" selected>Mr</option>
               </select>
               </div>
               <div class="form-group col-sm-5">
                  <label for="fname">First name</label>
                  <input type="text" class="form-control"
                     id="fname" placeholder="First name">
               </div>
               <div class="form-group col-sm-5">
                  <label for="lname">Last name</label>
                  <input type="lname" class="form-control"
                     id="lname" placeholder="Last name">
               </div>
               </div>
               <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="height">Height (m)</label>
                  <input type="text" class="form-control"
                     id="height" placeholder="Height">
               </div>
               <div class="form-group col-sm-6">
                  <label for="weight">Weight (Kg)</label>
                  <input type="text" class="form-control"
                     id="weight" placeholder="Weight">
               </div>
             </div>
             <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="date">Date of birth</label>
                  <input type="date" id="date" class="form-control"
      value="1998-05-24">
               </div>
               <div class="form-group col-sm-6">
                  <label for="age">Age category</label>
                  <input type="text" class="form-control"
                     id="age" placeholder="Age category ex : 20>..>30">
               </div>
             </div>
            <div class="form-group">
               <label for="inputAddress">Address</label>
               <input type="text" class="form-control"
                  id="myAddress" placeholder="1234 Main St">
            </div>
            <div class="form-group">
               <label for="inputAddress2">Address 2</label>
               <input type="text" class="form-control"
                  id="myAddress2" placeholder="Apartment, studio, or floor">
            </div>
            <div class="form-row">
               <div class="form-group col-sm-6">
                  <label for="myCity">City</label>
                  <input type="text" class="form-control" id="myCity">
               </div>
               <div class="form-group col-sm-4">
                  <label for="myState">State</label>
                  <select id="myState" class="form-control">
                     <option selected>Choose...</option>
                     <option>...</option>
                  </select>
               </div>
               <div class="form-group col-sm-2">
                  <label for="myZip">Zip</label>
                  <input type="text" class="form-control" id="myZip">
               </div>
            </div>
            <button type="submit" class="btn btn-primary">Sign up</button>
            <br><br>
            <br><br>
         </form>
</div>
         </body>
         <br><br>
</body>
<br><br>

</html>

<?php 
    include 'footer.php';
?>