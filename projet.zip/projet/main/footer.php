<footer>
        <div class="row ">
                <div class="col-6 text-center ">
                   
                        &copy; Copyright, 2021 - IMT Lille Douai - IDAW - iMangerMieux</a>
                    
                </div>
               
    </div>
</footer>
